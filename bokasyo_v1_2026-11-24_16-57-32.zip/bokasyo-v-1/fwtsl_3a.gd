extends Node2D
## Scene 2: press ESC to go back to the store (scene 1).

# Paste the path you copied in step 1 between the quotes.
const STORE_SCENE_PATH := "res://scenes/main.tscn"


func _input(event: InputEvent) -> void:
	var key := event as InputEventKey
	if key != null and key.pressed and not key.echo and key.keycode == KEY_ESCAPE:
		get_viewport().set_input_as_handled()
		var err := get_tree().change_scene_to_file(STORE_SCENE_PATH)
		if err != OK:
			push_error("Could not load scene: %s (error %d)" % [STORE_SCENE_PATH, err])
