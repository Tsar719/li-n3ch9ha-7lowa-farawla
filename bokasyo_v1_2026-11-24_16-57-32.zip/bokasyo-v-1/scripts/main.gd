extends Node2D
## Store scene: hover highlights, cash drawer, view switching (belt / register), transitions.
##
## Hover + click the conveyor belt  -> top-down view of the belt   (ESC = back)
## Hover + click the monitor        -> cashier terminal / calculator (ESC = back)
## Hover the cash drawer            -> the drawer opens, it closes when you move away
## The phone (P) can only be used in the normal store view.
##
## The belt, monitor and drawers are separate cut-out sprites (assets/cut/) placed on top
## of the store background, so highlights follow their real shape.

const Interactable := preload("res://scripts/interactable.gd")

enum View { STORE, BELT, REGISTER }

const SCREEN_SIZE := Vector2(1920, 1080)
const IMAGE_SCALE := 1920.0 / 1080.0   # store images are 1080 px wide
const FADE_TIME := 0.12                # seconds for each half of the transition
const BACK_ACTION := "back"

# name -> [cut-out image, highlight image, top-left position inside the 1080x608 store image]
const CUTS := {
	"belt": ["res://assets/cut/belt.png", "res://assets/cut/belt_hl.png", Vector2(413, 427)],
	"monitor": ["res://assets/cut/monitor.png", "res://assets/cut/monitor_hl.png", Vector2(106, 268)],
	"drawer_closed": ["res://assets/cut/drawer_closed.png", "res://assets/cut/drawer_closed_hl.png", Vector2(102, 432)],
	"drawer_open": ["res://assets/cut/drawer_open.png", "res://assets/cut/drawer_open_hl.png", Vector2(10, 432)],
}
const POINTER_IDS := ["belt", "monitor"]  # these show a hand cursor

var current_view: View = View.STORE

var _busy := false
var _objects := {}          # name -> Interactable
var _objects_root: Node2D
var _hovered_id := ""
var _drawer_open := false
var _fade: ColorRect

@onready var background: Sprite2D = $Background
@onready var belt_view: CanvasLayer = $BeltView
@onready var belt_image: Sprite2D = $BeltView/Image
@onready var register_view: CanvasLayer = $RegisterView
@onready var phone = $UI/Phone  # phone.gd (untyped on purpose: custom members)


func _ready() -> void:
	_ensure_input_action()

	belt_image.scale = Vector2(
		SCREEN_SIZE.x / belt_image.texture.get_width(),
		SCREEN_SIZE.y / belt_image.texture.get_height()
	)
	_build_belt_hint()
	_build_objects()
	_build_fade()
	_apply_view(View.STORE)


func _process(_delta: float) -> void:
	var id := ""
	if current_view == View.STORE and not _busy and phone.is_hidden():
		id = _hit_test(get_global_mouse_position())
	if id != _hovered_id:
		_set_hovered(id)


func _unhandled_input(event: InputEvent) -> void:
	if _busy:
		return
	if event.is_action_pressed(BACK_ACTION):
		if current_view != View.STORE:
			_go_to(View.STORE)
		return
	var click := event as InputEventMouseButton
	if current_view == View.STORE \
			and click != null \
			and click.pressed \
			and click.button_index == MOUSE_BUTTON_LEFT:
		match _hovered_id:
			"belt":
				_go_to(View.BELT)
			"monitor":
				_go_to(View.REGISTER)


# ------------------------------------------------------------------ hover handling

func _hit_test(mouse: Vector2) -> String:
	if _objects["monitor"].contains(mouse):
		return "monitor"
	var drawer = _objects["drawer_open"] if _drawer_open else _objects["drawer_closed"]
	if drawer.contains(mouse):
		return "drawer"
	if _objects["belt"].contains(mouse):
		return "belt"
	return ""


func _set_hovered(id: String) -> void:
	_hovered_id = id
	_objects["belt"].hovered = (id == "belt")
	_objects["monitor"].hovered = (id == "monitor")
	_set_drawer_open(id == "drawer")
	Input.set_default_cursor_shape(
		Input.CURSOR_POINTING_HAND if id in POINTER_IDS else Input.CURSOR_ARROW
	)


func _set_drawer_open(open: bool) -> void:
	_drawer_open = open
	_objects["drawer_closed"].visible = not open
	_objects["drawer_open"].visible = open
	_objects["drawer_open"].hovered = open  # outline around the opened drawer


# ------------------------------------------------------------------ views + transition

func _go_to(view: View) -> void:
	if _busy or view == current_view:
		return
	_busy = true
	var t := create_tween()
	t.tween_property(_fade, "color:a", 1.0, FADE_TIME)
	await t.finished
	_apply_view(view)
	t = create_tween()
	t.tween_property(_fade, "color:a", 0.0, FADE_TIME)
	await t.finished
	_busy = false


func _apply_view(view: View) -> void:
	current_view = view
	_set_hovered("")
	background.visible = view == View.STORE
	_objects_root.visible = view == View.STORE
	belt_view.visible = view == View.BELT
	register_view.visible = view == View.REGISTER
	register_view.set_active(view == View.REGISTER)
	phone.locked = view != View.STORE  # no phone while looking at the belt / the monitor


# ------------------------------------------------------------------ setup helpers

func _build_objects() -> void:
	_objects_root = Node2D.new()
	_objects_root.name = "Objects"
	add_child(_objects_root)
	for key in CUTS:
		var def: Array = CUTS[key]
		var obj = Interactable.new()  # interactable.gd
		obj.name = key.capitalize().replace(" ", "")
		obj.setup(load(def[0]), load(def[1]), def[2])
		_objects_root.add_child(obj)
		_objects[key] = obj


func _build_fade() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 20
	add_child(layer)
	_fade = ColorRect.new()
	_fade.color = Color(0, 0, 0, 0)
	_fade.size = SCREEN_SIZE
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(_fade)


func _build_belt_hint() -> void:
	var hint := Label.new()
	hint.text = "ESC  -  Back"
	hint.position = Vector2(40, 1010)
	hint.modulate = Color(1, 1, 1, 0.75)
	hint.add_theme_font_size_override("font_size", 28)
	belt_view.add_child(hint)


func _ensure_input_action() -> void:
	if InputMap.has_action(BACK_ACTION):
		return
	InputMap.add_action(BACK_ACTION)
	var ev := InputEventKey.new()
	ev.physical_keycode = KEY_ESCAPE
	InputMap.action_add_event(BACK_ACTION, ev)
