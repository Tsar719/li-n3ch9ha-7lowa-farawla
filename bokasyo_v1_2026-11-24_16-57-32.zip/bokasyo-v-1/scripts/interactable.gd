extends Sprite2D
## A cut-out object of the store scene (belt, monitor, drawer...).
## - shows a silhouette-shaped highlight (pulsing) while `hovered` is true
## - pixel-perfect hit test: only the visible (non-transparent) pixels count

const IMAGE_SCALE := 1920.0 / 1080.0   # store images are 1080 px wide, the game is 1920

var hovered := false:
	set(value):
		hovered = value
		if _highlight:
			_highlight.visible = value
			_highlight.modulate.a = 1.0
		set_process(value)

var _alpha_image: Image
var _highlight: Sprite2D


## cut: the object's image (RGBA), highlight: white silhouette outline (same size),
## origin: top-left position of the cut-out inside the 1080x608 store image.
func setup(cut: Texture2D, highlight: Texture2D, origin: Vector2) -> void:
	texture = cut
	centered = false
	scale = Vector2.ONE * IMAGE_SCALE
	position = origin * IMAGE_SCALE
	_alpha_image = cut.get_image()

	_highlight = Sprite2D.new()
	_highlight.texture = highlight
	_highlight.centered = false
	_highlight.visible = false
	add_child(_highlight)  # child of this sprite: same position and scale
	set_process(false)


func _process(_delta: float) -> void:
	_highlight.modulate.a = 0.82 + 0.18 * sin(Time.get_ticks_msec() * 0.008)


## point: global (1920x1080 screen) position
func contains(point: Vector2) -> bool:
	if not is_visible_in_tree() or _alpha_image == null:
		return false
	var p := to_local(point)
	var x := int(floor(p.x))
	var y := int(floor(p.y))
	if x < 0 or y < 0 or x >= _alpha_image.get_width() or y >= _alpha_image.get_height():
		return false
	return _alpha_image.get_pixel(x, y).a > 0.5
