extends Area2D
## The handheld scanner ("laser hand"): Area2D + sprite + CollisionShape2D.
## It follows the mouse. When it touches a Product, the product is scanned.

@export var require_click := false  # true = only scan while holding left mouse button


func _ready() -> void:
	area_entered.connect(_on_area_entered)


func _process(_delta: float) -> void:
	global_position = get_global_mouse_position()
	if require_click and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		for a in get_overlapping_areas():
			if a is Product:
				a.scan()


func _on_area_entered(area: Area2D) -> void:
	if not require_click and area is Product:
		area.scan()
