extends AnimatedSprite2D
## Phone pull-out animation + phone screen.
## P: pull the phone out (fast) -> the phone screen opens when the animation ends.
## P again: the screen closes and the phone is put away (fast).
## Frames: res://assets/phone/phone_000.png ... (only 0..FRAME_COUNT-1 are used)

signal phone_opened
signal phone_closed
signal app_pressed(app_name: String)

enum State { HIDDEN, PULLING, OPEN, PUTTING_AWAY }

const FRAME_DIR := "res://assets/phone/"
const FRAME_COUNT := 31          # motion is finished by frame 30, the rest is just hand wobble
const BASE_FPS := 30.0
const PULL_SPEED := 3.0          # 1.0 = original video speed. 3.0 -> ~0.35 s
const PUT_AWAY_SPEED := 4.0      # 4.0 -> ~0.25 s
const ANIM := "pull"
const SRC_SIZE := Vector2(480, 852)   # size of every frame in pixels
const PHONE_SCALE := 1.5              # visual size on the 1920x1080 screen
const SCREEN_SIZE := Vector2(1920, 1080)
const ACTION := "toggle_phone"

# Phone display area inside the last frame (frame pixel coordinates, before PHONE_SCALE)
const PHONE_SCREEN_RECT := Rect2(130, 266, 165, 348)

const APPS := ["Messages", "Notes", "Camera", "Settings"]
const DAYS := ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]

var state: State = State.HIDDEN
var locked := false   # set by main.gd: the phone cannot be pulled out while true
var _screen: Panel
var _time_label: Label
var _date_label: Label


func _ready() -> void:
	_ensure_input_action()

	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	centered = false
	scale = Vector2.ONE * PHONE_SCALE
	# Bottom-right of the screen (the arm leaves the frame there)
	var size := SRC_SIZE * PHONE_SCALE
	position = Vector2(SCREEN_SIZE.x - size.x, SCREEN_SIZE.y - size.y)

	var frames := SpriteFrames.new()
	if frames.has_animation("default"):
		frames.remove_animation("default")
	frames.add_animation(ANIM)
	frames.set_animation_speed(ANIM, BASE_FPS)
	frames.set_animation_loop(ANIM, false)
	for i in FRAME_COUNT:
		var tex: Texture2D = load("%sphone_%03d.png" % [FRAME_DIR, i])
		frames.add_frame(ANIM, tex)
	sprite_frames = frames
	animation = ANIM
	frame = 0
	visible = false

	_build_screen()
	animation_finished.connect(_on_animation_finished)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed(ACTION) and not event.is_echo():
		toggle_phone()


func _process(_delta: float) -> void:
	if state == State.OPEN:
		_update_clock()


func toggle_phone() -> void:
	match state:
		State.HIDDEN:
			if locked:
				return
			state = State.PULLING
			visible = true
			frame = 0
			play(ANIM, PULL_SPEED)
		State.OPEN:
			state = State.PUTTING_AWAY
			_screen.visible = false
			play(ANIM, -PUT_AWAY_SPEED, true)
			phone_closed.emit()
		_:
			pass  # ignore input while animating


func is_hidden() -> bool:
	return state == State.HIDDEN


func is_open() -> bool:
	return state == State.OPEN


func _on_animation_finished() -> void:
	match state:
		State.PULLING:
			state = State.OPEN
			_open_screen()
		State.PUTTING_AWAY:
			state = State.HIDDEN
			visible = false


func _open_screen() -> void:
	_update_clock()
	_screen.modulate.a = 0.0
	_screen.visible = true
	var tween := create_tween()
	tween.tween_property(_screen, "modulate:a", 1.0, 0.12)
	phone_opened.emit()


# ---------------------------------------------------------------- phone screen UI
# Built in code and parented to the sprite, so it uses the sprite's frame pixel
# coordinates and scales / moves together with it.

func _build_screen() -> void:
	_screen = Panel.new()
	_screen.position = PHONE_SCREEN_RECT.position
	_screen.size = PHONE_SCREEN_RECT.size
	_screen.clip_contents = true
	_screen.visible = false

	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0.06, 0.06, 0.07)
	bg.set_corner_radius_all(12)
	_screen.add_theme_stylebox_override("panel", bg)

	var box := VBoxContainer.new()
	box.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	box.offset_left = 8
	box.offset_right = -8
	box.offset_top = 14
	box.offset_bottom = -12
	box.add_theme_constant_override("separation", 6)
	_screen.add_child(box)

	_time_label = Label.new()
	_time_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_time_label.add_theme_font_size_override("font_size", 34)
	box.add_child(_time_label)

	_date_label = Label.new()
	_date_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_date_label.add_theme_font_size_override("font_size", 12)
	_date_label.modulate = Color(1, 1, 1, 0.6)
	box.add_child(_date_label)

	var spacer := Control.new()
	spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	box.add_child(spacer)

	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 6)
	grid.add_theme_constant_override("v_separation", 6)
	box.add_child(grid)

	for app_name in APPS:
		var b := Button.new()
		b.text = app_name
		b.focus_mode = Control.FOCUS_NONE  # keeps keyboard input (P) free
		b.custom_minimum_size = Vector2(70, 46)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.add_theme_font_size_override("font_size", 11)
		b.pressed.connect(_on_app_pressed.bind(app_name))
		grid.add_child(b)

	add_child(_screen)


func _update_clock() -> void:
	var t := Time.get_time_dict_from_system()
	_time_label.text = "%02d:%02d" % [t.hour, t.minute]
	var d := Time.get_date_dict_from_system()
	_date_label.text = "%s %02d/%02d" % [DAYS[d.weekday], d.day, d.month]


func _on_app_pressed(app_name: String) -> void:
	print("Phone app pressed: ", app_name)
	app_pressed.emit(app_name)


func _ensure_input_action() -> void:
	if InputMap.has_action(ACTION):
		return
	InputMap.add_action(ACTION)
	var ev := InputEventKey.new()
	ev.physical_keycode = KEY_P
	InputMap.action_add_event(ACTION, ev)
