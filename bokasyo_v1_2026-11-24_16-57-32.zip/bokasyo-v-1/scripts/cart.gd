class_name Cart
extends RefCounted
## Shared cart. Static variables stay alive when you change scenes,
## so no autoload is needed. Needs Godot 4.1 or newer.

static var items: Array[Dictionary] = []


static func add_item(item_name: String, price: float) -> void:
	items.append({"name": item_name, "price": price})


static func get_total() -> float:
	var total := 0.0
	for item in items:
		total += item["price"]
	return total


static func clear() -> void:
	items.clear()
