extends CanvasLayer
## Cashier terminal (the monitor view): a calculator screen + the bill of scanned products.
## Styled as an old green-phosphor CRT with VHS artifacts (scanlines, curvature,
## chromatic bleed, tracking band, noise, flicker, blinking cursor, tape counter).
## main.gd shows / hides this layer and calls set_active().
## The bill reads the shared Cart (scripts/cart.gd), filled by the products in scene 2.

signal result_confirmed(value: float)  # emitted when "=" is pressed

const SCREEN_RECT := Rect2(60, 50, 1800, 980)

# Phosphor palette. Swap these for amber: text (1.0, 0.72, 0.25), border (0.8, 0.5, 0.1).
const COL_BG := Color(0.0, 0.01, 0.005)
const COL_SCREEN := Color(0.02, 0.07, 0.04)
const COL_BORDER := Color(0.25, 0.75, 0.4)
const COL_TEXT := Color(0.6, 1.0, 0.65)
const COL_DIM := Color(0.3, 0.6, 0.38)
const COL_DISPLAY := Color(0.01, 0.04, 0.02)
const COL_KEY := Color(0.04, 0.12, 0.07)
const COL_KEY_OP := Color(0.07, 0.2, 0.11)
const COL_KEY_EQ := Color(0.12, 0.34, 0.18)
const COL_KEY_CLR := Color(0.25, 0.1, 0.07)

const CRT_SHADER := """
shader_type canvas_item;
uniform sampler2D screen_tex : hint_screen_texture, filter_linear, repeat_disable;
uniform float curvature = 0.07;

float hash(vec2 p) {
	return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

vec2 curve(vec2 uv) {
	uv = uv * 2.0 - 1.0;
	uv *= vec2(1.0 + pow(abs(uv.y), 2.0) * curvature, 1.0 + pow(abs(uv.x), 2.0) * curvature);
	return uv * 0.5 + 0.5;
}

void fragment() {
	vec2 uv = curve(SCREEN_UV);
	if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) {
		COLOR = vec4(0.0, 0.0, 0.0, 1.0);
	} else {
		// VHS tracking band drifting up the screen
		float band = fract(1.0 - TIME * 0.11);
		float t = smoothstep(0.045, 0.0, abs(uv.y - band));
		uv.x += t * 0.012 * sin(uv.y * 90.0 + TIME * 25.0);

		// tiny per-line horizontal jitter
		float row = floor(uv.y * 270.0);
		uv.x += (hash(vec2(row, floor(TIME * 12.0))) - 0.5) * 0.0012;

		// chromatic aberration
		float ab = 0.0018 + t * 0.004;
		vec3 c;
		c.r = texture(screen_tex, uv + vec2(ab, 0.0)).r;
		c.g = texture(screen_tex, uv).g;
		c.b = texture(screen_tex, uv - vec2(ab, 0.0)).b;

		// horizontal colour smear / glow
		vec3 smear = texture(screen_tex, uv + vec2(0.003, 0.0)).rgb + texture(screen_tex, uv - vec2(0.003, 0.0)).rgb;
		c = (c + smear * 0.18) / 1.36;
		c *= 1.12;

		// scanlines
		c *= 0.86 + 0.14 * sin(uv.y * 1080.0 * 3.14159);

		// noise + noisy tracking band
		float n = hash(uv * vec2(1920.0, 1080.0) + fract(TIME) * 100.0);
		c += (n - 0.5) * 0.07;
		c += t * n * 0.22;

		// flicker
		c *= 0.965 + 0.035 * sin(TIME * 55.0);

		// vignette
		float len = length((uv - 0.5) * vec2(1.0, 0.85));
		c *= mix(1.0, 0.45, smoothstep(0.3, 0.85, len));

		COLOR = vec4(c, 1.0);
	}
}
"""

# [label, stretch ratio] - every row adds up to 4
const ROWS := [
	[["C", 2], ["DEL", 1], ["÷", 1]],
	[["7", 1], ["8", 1], ["9", 1], ["×", 1]],
	[["4", 1], ["5", 1], ["6", 1], ["-", 1]],
	[["1", 1], ["2", 1], ["3", 1], ["+", 1]],
	[["0", 2], [".", 1], ["=", 1]],
]
const OPERATORS := ["+", "-", "×", "÷"]

var _active := false
var _entry := "0"      # number being typed / shown
var _acc := 0.0        # stored left-hand value
var _op := ""          # pending operator
var _fresh := true     # next digit starts a new number
var _expr := ""        # small line above the number
var _error := false

var _value_label: Label
var _expr_label: Label
var _clock_label: Label
var _tape_label: Label
var _bill_text: RichTextLabel
var _bill_total: Label
var _mono: SystemFont
var _blink := 0.0
var _cursor_on := true
var _tape := 0.0


func _ready() -> void:
	_build_ui()
	_refresh()
	_refresh_bill()
	set_active(false)


func set_active(value: bool) -> void:
	_active = value
	if value:
		_tape = 0.0
		_on_key("C")  # fresh calculator every time the terminal is opened
		_refresh_bill()  # show everything scanned in scene 2


func _process(delta: float) -> void:
	if not _active:
		return
	var t := Time.get_time_dict_from_system()
	_clock_label.text = "%02d:%02d" % [t.hour, t.minute]

	_tape += delta
	var s := int(_tape)
	var playing := fmod(_tape, 2.0) < 1.4
	_tape_label.text = "%s  %d:%02d:%02d" % ["PLAY >" if playing else "      ", s / 3600, (s / 60) % 60, s % 60]

	_blink += delta
	var on := fmod(_blink, 1.0) < 0.55
	if on != _cursor_on:
		_cursor_on = on
		_refresh()


func _unhandled_input(event: InputEvent) -> void:
	var key := event as InputEventKey
	if not _active or key == null or not key.pressed or key.echo:
		return
	match key.keycode:
		KEY_ENTER, KEY_KP_ENTER:
			_on_key("=")
		KEY_BACKSPACE:
			_on_key("DEL")
		KEY_DELETE:
			_on_key("C")
		_:
			if key.unicode <= 0:
				return
			var ch := char(key.unicode)
			if ch in ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", ".", "+", "-"]:
				_on_key(ch)
			elif ch == "*":
				_on_key("×")
			elif ch == "/":
				_on_key("÷")


# ------------------------------------------------------------------ calculator logic

func _on_key(k: String) -> void:
	if _error and k != "C":
		return
	match k:
		"C":
			_clear()
		"DEL":
			_backspace()
		"=":
			_equals()
		"+", "-", "×", "÷":
			_operator(k)
		_:
			_digit(k)
	_refresh()


func _clear() -> void:
	_entry = "0"
	_acc = 0.0
	_op = ""
	_fresh = true
	_expr = ""
	_error = false


func _digit(d: String) -> void:
	if _fresh:
		_entry = "0"
		_fresh = false
	if d == ".":
		if not _entry.contains("."):
			_entry += "."
		return
	if _entry.length() >= 12:
		return
	_entry = d if _entry == "0" else _entry + d


func _backspace() -> void:
	if _fresh:
		return
	if _entry.length() <= 1:
		_entry = "0"
	else:
		_entry = _entry.substr(0, _entry.length() - 1)


func _operator(op: String) -> void:
	if _op != "" and not _fresh:
		_acc = _compute(_acc, _op, float(_entry))
		if _error:
			return
		_entry = _fmt(_acc)
	else:
		_acc = float(_entry)
	_op = op
	_fresh = true
	_expr = "%s %s" % [_fmt(_acc), op]


func _equals() -> void:
	if _op == "":
		result_confirmed.emit(float(_entry))
		return
	var rhs := float(_entry)
	var res := _compute(_acc, _op, rhs)
	if _error:
		return
	_expr = "%s %s %s =" % [_fmt(_acc), _op, _fmt(rhs)]
	_entry = _fmt(res)
	_acc = res
	_op = ""
	_fresh = true
	result_confirmed.emit(res)


func _compute(a: float, op: String, b: float) -> float:
	match op:
		"+":
			return a + b
		"-":
			return a - b
		"×":
			return a * b
		"÷":
			if is_zero_approx(b):
				_error = true
				_entry = "ERROR"
				_expr = ""
				return 0.0
			return a / b
	return b


func _fmt(v: float) -> String:
	var s := "%.4f" % v
	if s.contains("."):
		s = s.rstrip("0").rstrip(".")
	if s == "-0" or s == "":
		s = "0"
	return s


func _refresh() -> void:
	# blinking block cursor; a space when "off" keeps the digits from shifting
	var cursor := "_" if (_cursor_on and not _error) else " "
	_value_label.text = _entry + cursor
	_expr_label.text = _expr


# ------------------------------------------------------------------ bill (scanned products)

func _refresh_bill() -> void:
	var lines := PackedStringArray()
	for item in Cart.items:
		lines.append("%-22s%8.2f" % [String(item["name"]).substr(0, 22), item["price"]])
	if lines.is_empty():
		lines.append("(nothing scanned yet)")
	_bill_text.text = "\n".join(lines)
	_bill_total.text = "TOTAL  %.2f" % Cart.get_total()


func _on_new_customer() -> void:
	Cart.clear()
	_refresh_bill()


# ------------------------------------------------------------------ UI

func _build_ui() -> void:
	_mono = SystemFont.new()
	_mono.font_names = PackedStringArray(["Courier New", "Consolas", "Lucida Console", "monospace"])

	var root := Control.new()
	root.size = Vector2(1920, 1080)
	add_child(root)

	var bg := ColorRect.new()
	bg.color = COL_BG
	bg.size = Vector2(1920, 1080)
	root.add_child(bg)

	var screen := Panel.new()
	screen.position = SCREEN_RECT.position
	screen.size = SCREEN_RECT.size
	screen.add_theme_stylebox_override("panel", _box(COL_SCREEN, COL_BORDER, 4, 6))
	root.add_child(screen)

	var margin := MarginContainer.new()
	margin.size = SCREEN_RECT.size
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 36)
	screen.add_child(margin)

	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 20)
	margin.add_child(col)

	# header
	var header := HBoxContainer.new()
	col.add_child(header)
	var title := _label("> CASHIER TERMINAL 01", 34, COL_TEXT)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title)
	_clock_label = _label("00:00", 34, COL_DIM)
	header.add_child(_clock_label)

	# body: calculator on the left, bill on the right
	var body := HBoxContainer.new()
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 28)
	col.add_child(body)

	var left := VBoxContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.size_flags_stretch_ratio = 3.0
	left.add_theme_constant_override("separation", 20)
	body.add_child(left)

	# display
	var display := PanelContainer.new()
	var ds := _box(COL_DISPLAY, COL_BORDER, 2, 4)
	ds.set_content_margin_all(20)
	display.add_theme_stylebox_override("panel", ds)
	display.custom_minimum_size = Vector2(0, 190)
	left.add_child(display)
	var dv := VBoxContainer.new()
	display.add_child(dv)
	_expr_label = _label("", 30, COL_DIM)
	_expr_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	dv.add_child(_expr_label)
	_value_label = _label("0", 96, COL_TEXT)
	_value_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	dv.add_child(_value_label)

	# keypad
	var pad := VBoxContainer.new()
	pad.size_flags_vertical = Control.SIZE_EXPAND_FILL
	pad.add_theme_constant_override("separation", 14)
	left.add_child(pad)
	for row in ROWS:
		var hb := HBoxContainer.new()
		hb.size_flags_vertical = Control.SIZE_EXPAND_FILL
		hb.add_theme_constant_override("separation", 14)
		pad.add_child(hb)
		for key in row:
			hb.add_child(_make_key(key[0], key[1]))

	# bill panel (scanned products)
	var bill := PanelContainer.new()
	var bs := _box(COL_DISPLAY, COL_BORDER, 2, 4)
	bs.set_content_margin_all(20)
	bill.add_theme_stylebox_override("panel", bs)
	bill.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bill.size_flags_stretch_ratio = 2.0
	body.add_child(bill)
	var bv := VBoxContainer.new()
	bv.add_theme_constant_override("separation", 12)
	bill.add_child(bv)
	bv.add_child(_label("> BILL", 34, COL_TEXT))
	_bill_text = RichTextLabel.new()
	_bill_text.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_bill_text.scroll_following = true
	_bill_text.add_theme_font_override("normal_font", _mono)
	_bill_text.add_theme_font_size_override("normal_font_size", 28)
	_bill_text.add_theme_color_override("default_color", COL_TEXT)
	bv.add_child(_bill_text)
	_bill_total = _label("TOTAL  0.00", 44, COL_TEXT)
	_bill_total.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	bv.add_child(_bill_total)

	# NEW CUSTOMER button: empties the bill
	var new_btn := _make_key("NEW CUSTOMER", 1)
	new_btn.add_theme_font_size_override("font_size", 30)
	new_btn.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	new_btn.custom_minimum_size = Vector2(0, 70)
	new_btn.pressed.disconnect(_on_key.bind("NEW CUSTOMER"))
	new_btn.pressed.connect(_on_new_customer)
	bv.add_child(new_btn)

	# footer: hint on the left, VHS tape counter on the right
	var footer := HBoxContainer.new()
	col.add_child(footer)
	var hint := _label("ESC  -  leave terminal", 24, COL_DIM)
	hint.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	footer.add_child(hint)
	_tape_label = _label("PLAY >  0:00:00", 24, COL_DIM)
	footer.add_child(_tape_label)

	# CRT / VHS post-process overlay (must be last; never blocks the mouse)
	var shader := Shader.new()
	shader.code = CRT_SHADER
	var mat := ShaderMaterial.new()
	mat.shader = shader
	var crt := ColorRect.new()
	crt.size = Vector2(1920, 1080)
	crt.mouse_filter = Control.MOUSE_FILTER_IGNORE
	crt.material = mat
	root.add_child(crt)


func _make_key(text: String, ratio: int) -> Button:
	var color := COL_KEY
	if text == "=":
		color = COL_KEY_EQ
	elif text == "C":
		color = COL_KEY_CLR
	elif text in OPERATORS or text == "DEL":
		color = COL_KEY_OP
	var b := Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE  # keep the keyboard free
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.size_flags_vertical = Control.SIZE_EXPAND_FILL
	b.size_flags_stretch_ratio = ratio
	b.add_theme_font_override("font", _mono)
	b.add_theme_font_size_override("font_size", 52)
	b.add_theme_color_override("font_color", COL_TEXT)
	b.add_theme_color_override("font_hover_color", Color.WHITE)
	b.add_theme_stylebox_override("normal", _box(color, COL_BORDER, 2, 4))
	b.add_theme_stylebox_override("hover", _box(color.lightened(0.15), COL_TEXT, 2, 4))
	b.add_theme_stylebox_override("pressed", _box(color.darkened(0.3), COL_TEXT, 2, 4))
	b.pressed.connect(_on_key.bind(text))
	return b


func _label(text: String, font_size: int, color: Color) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_override("font", _mono)
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", color)
	return l


func _box(fill: Color, border: Color, border_width: int, radius: int) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = fill
	s.border_color = border
	s.set_border_width_all(border_width)
	s.set_corner_radius_all(radius)
	return s
