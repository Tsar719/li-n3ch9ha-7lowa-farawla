class_name Product
extends Area2D
## Put this on every product (Cheetos, Nido, ...): Area2D + Sprite2D + CollisionShape2D.
## Set "product_name" and "price" in the Inspector for each product scene.

signal scanned(product: Product)

@export var product_name := "Cheetos"
@export var price := 1.50

var _scanned := false


func _ready() -> void:
	add_to_group("products")


## Called by the scanner. Adds the item to the bill, then it disappears.
func scan() -> void:
	if _scanned:
		return
	_scanned = true
	scanned.emit(self)
	var tw := create_tween()
	tw.tween_property(self, "scale", Vector2.ZERO, 0.15)
	tw.tween_callback(queue_free)
